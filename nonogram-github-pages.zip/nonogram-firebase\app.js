(function () {
  const text = {
    localMode: "\ub85c\uceec \ubaa8\ub4dc",
    firebaseOnline: "Firebase \uc5f0\uacb0\ub428",
    firebaseNeedsSetup: "Firebase \uc124\uc815 \ud655\uc778 \ud544\uc694",
    savedLocal: "\ub85c\uceec \uc800\uc7a5\ub428",
    saving: "\uc800\uc7a5 \uc911",
    savedFirebase: "Firebase \uc800\uc7a5\ub428",
    choosePuzzle: "\ud37c\uc990\uc744 \uc120\ud0dd\ud558\uace0 \uce78\uc744 \ucc44\uc6cc\ubcf4\uc138\uc694.",
    progressSaved: "\uc9c4\ud589 \uc0c1\ud669\uc774 \uc800\uc7a5\ub429\ub2c8\ub2e4.",
    solved: "\uc815\ub2f5\uc785\ub2c8\ub2e4. \ud65c\ub3d9 \uae30\ub85d\uc774 \uc800\uc7a5\ub418\uc5c8\uc2b5\ub2c8\ub2e4.",
    notSolved: "\uc544\uc9c1 \ub2e4\ub978 \uce78\uc774 \uc788\uc5b4\uc694. \ud45c\uc2dc\ub41c \uce78\uc744 \ub2e4\uc2dc \ud655\uc778\ud558\uc138\uc694.",
    restart: "\uc0c8\ub85c \uc2dc\uc791\ud569\ub2c8\ub2e4.",
    noSessions: "\uc544\uc9c1 \ubd88\ub7ec\uc62c \ud559\uc0dd \uacb0\uacfc\uac00 \uc5c6\uc2b5\ub2c8\ub2e4.",
    loadedSessions: "\uac1c\uc758 \uacb0\uacfc\ub97c \ubd88\ub7ec\uc654\uc2b5\ub2c8\ub2e4.",
    converted: "\uc774\ubbf8\uc9c0\ub97c \ud37c\uc990\ub85c \ubcc0\ud658\ud588\uc2b5\ub2c8\ub2e4.",
    savedPuzzle: "\ud37c\uc990 \ubaa9\ub85d\uc5d0 \ucd94\uac00\ud588\uc2b5\ub2c8\ub2e4."
  };

  const builtInPuzzles = [
    {
      id: "heart-5",
      title: "\ud558\ud2b8 5x5",
      grid: [
        [0, 1, 0, 1, 0],
        [1, 1, 1, 1, 1],
        [1, 1, 1, 1, 1],
        [0, 1, 1, 1, 0],
        [0, 0, 1, 0, 0]
      ]
    },
    {
      id: "house-7",
      title: "\uc9d1 7x7",
      grid: [
        [0, 0, 0, 1, 0, 0, 0],
        [0, 0, 1, 1, 1, 0, 0],
        [0, 1, 1, 1, 1, 1, 0],
        [1, 1, 1, 1, 1, 1, 1],
        [0, 1, 1, 1, 1, 1, 0],
        [0, 1, 0, 1, 0, 1, 0],
        [0, 1, 1, 1, 1, 1, 0]
      ]
    },
    {
      id: "smile-8",
      title: "\uc6c3\ub294 \uc5bc\uad74 8x8",
      grid: [
        [0, 1, 1, 1, 1, 1, 1, 0],
        [1, 0, 0, 0, 0, 0, 0, 1],
        [1, 0, 1, 0, 0, 1, 0, 1],
        [1, 0, 0, 0, 0, 0, 0, 1],
        [1, 0, 1, 0, 0, 1, 0, 1],
        [1, 0, 0, 1, 1, 0, 0, 1],
        [1, 0, 0, 0, 0, 0, 0, 1],
        [0, 1, 1, 1, 1, 1, 1, 0]
      ]
    }
  ];

  const els = {
    tabs: document.querySelectorAll(".tab"),
    panels: document.querySelectorAll(".tab-panel"),
    board: document.getElementById("board"),
    puzzleSelect: document.getElementById("puzzleSelect"),
    reviewPuzzleSelect: document.getElementById("reviewPuzzleSelect"),
    mergePuzzleSelect: document.getElementById("mergePuzzleSelect"),
    splitPuzzleSelect: document.getElementById("splitPuzzleSelect"),
    pieceSize: document.getElementById("pieceSize"),
    splitPuzzleBtn: document.getElementById("splitPuzzleBtn"),
    savePiecesBtn: document.getElementById("savePiecesBtn"),
    deletePiecesBtn: document.getElementById("deletePiecesBtn"),
    deleteAllPiecesBtn: document.getElementById("deleteAllPiecesBtn"),
    pieceSummary: document.getElementById("pieceSummary"),
    piecePreview: document.getElementById("piecePreview"),
    combineParentSelect: document.getElementById("combineParentSelect"),
    combinePiecesBtn: document.getElementById("combinePiecesBtn"),
    saveCombinedBtn: document.getElementById("saveCombinedBtn"),
    combinePieceSummary: document.getElementById("combinePieceSummary"),
    combinedPiecePreview: document.getElementById("combinedPiecePreview"),
    studentName: document.getElementById("studentName"),
    connectionStatus: document.getElementById("connectionStatus"),
    saveStatus: document.getElementById("saveStatus"),
    filledCount: document.getElementById("filledCount"),
    mistakeCount: document.getElementById("mistakeCount"),
    timer: document.getElementById("timer"),
    message: document.getElementById("message"),
    paintTool: document.getElementById("paintTool"),
    markTool: document.getElementById("markTool"),
    eraseTool: document.getElementById("eraseTool"),
    checkBtn: document.getElementById("checkBtn"),
    resetBtn: document.getElementById("resetBtn"),
    deletePuzzleBtn: document.getElementById("deletePuzzleBtn"),
    deleteAllGeneratedBtn: document.getElementById("deleteAllGeneratedBtn"),
    loadSessionsBtn: document.getElementById("loadSessionsBtn"),
    reviewSummary: document.getElementById("reviewSummary"),
    sessionList: document.getElementById("sessionList"),
    sessionPreview: document.getElementById("sessionPreview"),
    mergeMode: document.getElementById("mergeMode"),
    mergeBtn: document.getElementById("mergeBtn"),
    saveMergedBtn: document.getElementById("saveMergedBtn"),
    mergedPuzzleTitle: document.getElementById("mergedPuzzleTitle"),
    mergeSummary: document.getElementById("mergeSummary"),
    mergePreview: document.getElementById("mergePreview"),
    imageInput: document.getElementById("imageInput"),
    imageCanvas: document.getElementById("imageCanvas"),
    gridWidth: document.getElementById("gridWidth"),
    gridHeight: document.getElementById("gridHeight"),
    threshold: document.getElementById("threshold"),
    invertImage: document.getElementById("invertImage"),
    convertBtn: document.getElementById("convertBtn"),
    saveConvertedBtn: document.getElementById("saveConvertedBtn"),
    convertedPuzzleTitle: document.getElementById("convertedPuzzleTitle"),
    convertSummary: document.getElementById("convertSummary"),
    convertPreview: document.getElementById("convertPreview")
  };

  let db = null;
  let puzzles = builtInPuzzles.slice();
  let currentPuzzle = puzzles[0];
  let state = [];
  let tool = "paint";
  let startedAt = Date.now();
  let seconds = 0;
  let saveTimer = null;
  let loadedSessions = [];
  let mergedGrid = null;
  let convertedGrid = null;
  let splitPieces = [];
  let combinedPieceGrid = null;
  let uploadedImage = null;

  function setupFirebase() {
    const config = window.NONOGRAM_FIREBASE_CONFIG || {};
    const configured = Boolean(config.apiKey && config.projectId && window.firebase);

    if (!configured) {
      setConnection(text.localMode, "neutral");
      return;
    }

    try {
      firebase.initializeApp(config);
      db = firebase.firestore();
      setConnection(text.firebaseOnline, "online");
    } catch (error) {
      console.warn(error);
      setConnection(text.firebaseNeedsSetup, "error");
    }
  }

  function setConnection(label, type) {
    els.connectionStatus.textContent = label;
    els.connectionStatus.className = "pill " + type;
  }

  function setSaveStatus(label, type) {
    els.saveStatus.textContent = label;
    els.saveStatus.className = "pill " + (type || "");
  }

  function clampGridSize(value) {
    return Math.max(5, Math.min(40, Number(value) || 20));
  }

  function normalizeGrid(grid) {
    return grid.map((row) => row.map((value) => value === 1 ? 1 : 0));
  }

  function cluesFor(line) {
    const clues = [];
    let count = 0;
    line.forEach((value) => {
      if (value) {
        count += 1;
      } else if (count) {
        clues.push(count);
        count = 0;
      }
    });
    if (count) clues.push(count);
    return clues.length ? clues : [0];
  }

  function makeBlankState(grid) {
    return grid.map((row) => row.map(() => 0));
  }

  function localCustomPuzzles() {
    try {
      return JSON.parse(localStorage.getItem("nonogramCustomPuzzles") || "[]");
    } catch (error) {
      console.warn(error);
      return [];
    }
  }

  function saveLocalCustomPuzzle(puzzle) {
    const custom = localCustomPuzzles().filter((item) => item.id !== puzzle.id);
    custom.push(puzzle);
    localStorage.setItem("nonogramCustomPuzzles", JSON.stringify(custom));
  }

  function removeLocalCustomPuzzles(ids) {
    const removeSet = new Set(ids);
    const custom = localCustomPuzzles().filter((item) => !removeSet.has(item.id));
    localStorage.setItem("nonogramCustomPuzzles", JSON.stringify(custom));
  }

  function isBuiltInPuzzle(puzzleId) {
    return builtInPuzzles.some((puzzle) => puzzle.id === puzzleId);
  }

  async function loadPuzzles() {
    const custom = localCustomPuzzles();
    const byId = new Map();
    builtInPuzzles.concat(custom).forEach((puzzle) => byId.set(puzzle.id, puzzle));

    if (db) {
      try {
        const snapshot = await db.collection("nonogramPuzzles").get();
        snapshot.forEach((doc) => {
          const data = doc.data();
          if (data && Array.isArray(data.grid)) {
            byId.set(doc.id, {
              id: doc.id,
              title: data.title || doc.id,
              grid: normalizeGrid(data.grid),
              parentId: data.parentId || null,
              parentTitle: data.parentTitle || "",
              piece: data.piece || null
            });
          }
        });
      } catch (error) {
        console.warn(error);
      }
    }

    puzzles = Array.from(byId.values());
    currentPuzzle = puzzles.find((puzzle) => puzzle.id === currentPuzzle.id) || puzzles[0];
    hydratePuzzleSelects();
  }

  function hydratePuzzleSelects() {
    [els.puzzleSelect, els.reviewPuzzleSelect, els.mergePuzzleSelect, els.splitPuzzleSelect].forEach((select) => {
      const selected = select.value;
      select.innerHTML = "";
      puzzles.forEach((puzzle) => {
        const option = document.createElement("option");
        option.value = puzzle.id;
        option.textContent = `${puzzle.title} (${puzzle.grid[0].length}x${puzzle.grid.length})`;
        select.appendChild(option);
      });
      if (puzzles.some((puzzle) => puzzle.id === selected)) {
        select.value = selected;
      }
    });

    hydrateParentSelect();
    els.puzzleSelect.value = currentPuzzle.id;
    els.reviewPuzzleSelect.value = currentPuzzle.id;
    els.mergePuzzleSelect.value = currentPuzzle.id;
    els.splitPuzzleSelect.value = currentPuzzle.id;
  }

  function hydrateParentSelect() {
    const selected = els.combineParentSelect.value;
    const parents = puzzles.filter((puzzle) => !puzzle.parentId);
    els.combineParentSelect.innerHTML = "";
    parents.forEach((puzzle) => {
      const option = document.createElement("option");
      option.value = puzzle.id;
      option.textContent = `${puzzle.title} (${puzzle.grid[0].length}x${puzzle.grid.length})`;
      els.combineParentSelect.appendChild(option);
    });
    if (parents.some((puzzle) => puzzle.id === selected)) {
      els.combineParentSelect.value = selected;
    } else if (currentPuzzle && !currentPuzzle.parentId) {
      els.combineParentSelect.value = currentPuzzle.id;
    }
  }

  function cellSizeFor(grid) {
    const width = grid[0].length;
    const height = grid.length;
    const maxSide = Math.max(width, height);
    if (maxSide > 32) return 18;
    if (maxSide > 24) return 22;
    if (maxSide > 16) return 28;
    if (maxSide > 10) return 34;
    return 44;
  }

  function renderBoard() {
    const rowCount = currentPuzzle.grid.length;
    const colCount = currentPuzzle.grid[0].length;
    const size = cellSizeFor(currentPuzzle.grid);
    const clueSize = Math.max(58, size * 2);
    const columns = [`${clueSize}px`].concat(Array(colCount).fill(`${size}px`)).join(" ");
    els.board.style.gridTemplateColumns = columns;
    els.board.style.setProperty("--cell-size", `${size}px`);
    els.board.innerHTML = "";

    const corner = document.createElement("div");
    corner.className = "corner";
    els.board.appendChild(corner);

    for (let col = 0; col < colCount; col += 1) {
      const line = currentPuzzle.grid.map((row) => row[col]);
      const clue = document.createElement("div");
      clue.className = "clue";
      clue.textContent = cluesFor(line).join("\n");
      els.board.appendChild(clue);
    }

    for (let row = 0; row < rowCount; row += 1) {
      const clue = document.createElement("div");
      clue.className = "clue";
      clue.textContent = cluesFor(currentPuzzle.grid[row]).join(" ");
      els.board.appendChild(clue);

      for (let col = 0; col < colCount; col += 1) {
        const cell = document.createElement("div");
        cell.className = "cell";
        cell.dataset.row = String(row);
        cell.dataset.col = String(col);
        if (state[row][col] === 1) cell.classList.add("filled");
        if (state[row][col] === 2) cell.classList.add("marked");

        const button = document.createElement("button");
        button.type = "button";
        button.setAttribute("aria-label", `row ${row + 1}, column ${col + 1}`);
        button.addEventListener("click", () => updateCell(row, col));
        cell.appendChild(button);
        els.board.appendChild(cell);
      }
    }

    updateStats();
  }

  function updateCell(row, col) {
    if (tool === "paint") state[row][col] = state[row][col] === 1 ? 0 : 1;
    if (tool === "mark") state[row][col] = state[row][col] === 2 ? 0 : 2;
    if (tool === "erase") state[row][col] = 0;
    els.message.className = "message";
    els.message.textContent = text.progressSaved;
    renderBoard();
    queueSave();
  }

  function setTool(nextTool) {
    tool = nextTool;
    els.paintTool.classList.toggle("active", tool === "paint");
    els.markTool.classList.toggle("active", tool === "mark");
    els.eraseTool.classList.toggle("active", tool === "erase");
  }

  function updateStats() {
    let filled = 0;
    let mistakes = 0;

    state.forEach((row, rowIndex) => {
      row.forEach((value, colIndex) => {
        if (value === 1) {
          filled += 1;
          if (currentPuzzle.grid[rowIndex][colIndex] !== 1) mistakes += 1;
        }
      });
    });

    els.filledCount.textContent = String(filled);
    els.mistakeCount.textContent = String(mistakes);
  }

  function checkAnswer() {
    let solved = true;
    document.querySelectorAll(".cell").forEach((cell) => cell.classList.remove("wrong"));

    state.forEach((row, rowIndex) => {
      row.forEach((value, colIndex) => {
        const shouldFill = currentPuzzle.grid[rowIndex][colIndex] === 1;
        const didFill = value === 1;
        if (shouldFill !== didFill) {
          solved = false;
          const selector = `.cell[data-row="${rowIndex}"][data-col="${colIndex}"]`;
          const cell = document.querySelector(selector);
          if (cell) cell.classList.add("wrong");
        }
      });
    });

    els.message.className = solved ? "message success" : "message error";
    els.message.textContent = solved ? text.solved : text.notSolved;
    saveProgress(solved);
  }

  function storageKey() {
    const name = (els.studentName.value || "guest").trim().replace(/\s+/g, "_");
    return `nonogram:${name}:${currentPuzzle.id}`;
  }

  function sessionDocId() {
    const name = (els.studentName.value || "guest").trim().replace(/[^\w-]+/g, "_");
    return `${name || "guest"}_${currentPuzzle.id}`;
  }

  function localSessionIndex() {
    try {
      return JSON.parse(localStorage.getItem("nonogramSessionIndex") || "[]");
    } catch (error) {
      console.warn(error);
      return [];
    }
  }

  function rememberLocalSession(key) {
    const index = localSessionIndex().filter((item) => item !== key);
    index.unshift(key);
    localStorage.setItem("nonogramSessionIndex", JSON.stringify(index.slice(0, 300)));
  }

  function removeLocalSessionsForPuzzleIds(ids) {
    const removeSet = new Set(ids);
    const nextIndex = [];
    localSessionIndex().forEach((key) => {
      const raw = localStorage.getItem(key);
      if (!raw) return;
      try {
        const data = JSON.parse(raw);
        if (removeSet.has(data.puzzleId)) {
          localStorage.removeItem(key);
        } else {
          nextIndex.push(key);
        }
      } catch (error) {
        console.warn(error);
        nextIndex.push(key);
      }
    });
    localStorage.setItem("nonogramSessionIndex", JSON.stringify(nextIndex));
  }

  async function deleteFirebasePuzzleData(ids) {
    if (!db) return;
    for (const id of ids) {
      try {
        await db.collection("nonogramPuzzles").doc(id).delete();
        const snapshot = await db.collection("nonogramSessions").where("puzzleId", "==", id).get();
        const deletes = [];
        snapshot.forEach((doc) => deletes.push(doc.ref.delete()));
        await Promise.all(deletes);
      } catch (error) {
        console.warn(error);
      }
    }
  }

  function queueSave() {
    setSaveStatus(text.saving, "");
    window.clearTimeout(saveTimer);
    saveTimer = window.setTimeout(() => saveProgress(false), 450);
  }

  async function saveProgress(solved) {
    const payload = {
      studentName: els.studentName.value.trim() || "guest",
      puzzleId: currentPuzzle.id,
      puzzleTitle: currentPuzzle.title,
      parentId: currentPuzzle.parentId || null,
      parentTitle: currentPuzzle.parentTitle || "",
      piece: currentPuzzle.piece || null,
      state: state,
      seconds: seconds + Math.floor((Date.now() - startedAt) / 1000),
      solved: Boolean(solved),
      width: currentPuzzle.grid[0].length,
      height: currentPuzzle.grid.length,
      updatedAt: new Date().toISOString()
    };

    const key = storageKey();
    localStorage.setItem(key, JSON.stringify(payload));
    rememberLocalSession(key);

    if (!db) {
      setSaveStatus(text.savedLocal, "");
      return;
    }

    try {
      await db.collection("nonogramSessions").doc(sessionDocId()).set({
        ...payload,
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      }, { merge: true });
      setSaveStatus(text.savedFirebase, "online");
    } catch (error) {
      console.warn(error);
      setSaveStatus(text.savedLocal, "error");
    }
  }

  function loadProgress() {
    const saved = localStorage.getItem(storageKey());
    if (!saved) return false;

    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed.state)) {
        state = parsed.state;
        seconds = Number(parsed.seconds) || 0;
        return true;
      }
    } catch (error) {
      console.warn(error);
    }

    return false;
  }

  function resetPuzzle() {
    state = makeBlankState(currentPuzzle.grid);
    seconds = 0;
    startedAt = Date.now();
    localStorage.removeItem(storageKey());
    els.message.className = "message";
    els.message.textContent = text.restart;
    renderBoard();
    queueSave();
  }

  function changePuzzle(puzzleId) {
    currentPuzzle = puzzles.find((puzzle) => puzzle.id === puzzleId) || puzzles[0];
    state = makeBlankState(currentPuzzle.grid);
    seconds = 0;
    startedAt = Date.now();
    loadProgress();
    els.puzzleSelect.value = currentPuzzle.id;
    els.reviewPuzzleSelect.value = currentPuzzle.id;
    els.mergePuzzleSelect.value = currentPuzzle.id;
    els.message.className = "message";
    els.message.textContent = text.choosePuzzle;
    renderBoard();
  }

  async function deleteSelectedPuzzle() {
    const target = currentPuzzle;
    if (!target) return;

    if (isBuiltInPuzzle(target.id)) {
      els.message.className = "message error";
      els.message.textContent = "\uae30\ubcf8 \ud37c\uc990\uc740 \uc9c0\uc6b8 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.";
      return;
    }

    const ok = !window.confirm || window.confirm(`"${target.title}" \ud37c\uc990\uacfc \uad00\ub828 \ud480\uc774 \uae30\ub85d\uc744 \uc9c0\uc6b8\uae4c\uc694?`);
    if (!ok) return;

    await deletePuzzlesByIds([target.id]);
    const next = puzzles.find((puzzle) => puzzle.id !== target.id) || builtInPuzzles[0];
    currentPuzzle = next;
    changePuzzle(next.id);
    els.message.className = "message success";
    els.message.textContent = "\uc120\ud0dd\ud55c \ud37c\uc990\uc744 \uc9c0\uc6e0\uc2b5\ub2c8\ub2e4.";
  }

  async function deletePiecesForSelectedParent() {
    const parentId = els.combineParentSelect.value || els.splitPuzzleSelect.value;
    const parent = puzzles.find((puzzle) => puzzle.id === parentId);
    const pieces = puzzles.filter((puzzle) => puzzle.parentId === parentId && !isBuiltInPuzzle(puzzle.id));

    if (!parent || !pieces.length) {
      els.pieceSummary.textContent = "\uc9c0\uc6b8 \uc870\uac01 \ud37c\uc990\uc774 \uc5c6\uc2b5\ub2c8\ub2e4.";
      return;
    }

    const ok = !window.confirm || window.confirm(`"${parent.title}"\uc758 \uc870\uac01 ${pieces.length}\uac1c\ub97c \uc9c0\uc6b8\uae4c\uc694?`);
    if (!ok) return;

    await deletePuzzlesByIds(pieces.map((piece) => piece.id));
    splitPieces = [];
    combinedPieceGrid = null;
    els.piecePreview.innerHTML = "";
    els.combinedPiecePreview.innerHTML = "";
    els.pieceSummary.textContent = `${pieces.length}\uac1c \uc870\uac01 \ud37c\uc990\uc744 \uc9c0\uc6e0\uc2b5\ub2c8\ub2e4.`;
    els.combinePieceSummary.textContent = "\uc870\uac01 \ud37c\uc990\uc744 \ub2e4\uc2dc \ucd94\uac00\ud558\uba74 \ud559\uc0dd\uc5d0\uac8c \ubc30\uc815\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4.";
  }

  async function deleteAllPieces() {
    const pieces = puzzles.filter((puzzle) => puzzle.parentId && !isBuiltInPuzzle(puzzle.id));

    if (!pieces.length) {
      els.pieceSummary.textContent = "\uc9c0\uc6b8 \uc870\uac01 \ud37c\uc990\uc774 \uc5c6\uc2b5\ub2c8\ub2e4.";
      return;
    }

    const ok = !window.confirm || window.confirm(`\ubaa8\ub4e0 \uc870\uac01 \ud37c\uc990 ${pieces.length}\uac1c\uc640 \uad00\ub828 \ud480\uc774 \uae30\ub85d\uc744 \uc804\ubd80 \uc9c0\uc6b8\uae4c\uc694?`);
    if (!ok) return;

    await deletePuzzlesByIds(pieces.map((piece) => piece.id));
    splitPieces = [];
    combinedPieceGrid = null;
    els.piecePreview.innerHTML = "";
    els.combinedPiecePreview.innerHTML = "";
    els.pieceSummary.textContent = `${pieces.length}\uac1c \uc870\uac01 \ud37c\uc990\uc744 \uc804\ubd80 \uc9c0\uc6e0\uc2b5\ub2c8\ub2e4.`;
    els.combinePieceSummary.textContent = "\uc870\uac01 \ud480\uc774 \uae30\ub85d\ub3c4 \ud568\uaed8 \uc815\ub9ac\ud588\uc2b5\ub2c8\ub2e4.";
  }

  async function deleteAllGenerated() {
    const generated = puzzles.filter((puzzle) => !isBuiltInPuzzle(puzzle.id));

    if (!generated.length) {
      els.message.className = "message error";
      els.message.textContent = "\uc9c0\uc6b8 \uc0dd\uc131 \ud37c\uc990\uc774 \uc5c6\uc2b5\ub2c8\ub2e4.";
      return;
    }

    const ok = !window.confirm || window.confirm(`\uae30\ubcf8 \uc0d8\ud50c\uc744 \uc81c\uc678\ud55c \uc0dd\uc131 \ud37c\uc990 ${generated.length}\uac1c\uc640 \uad00\ub828 \ud480\uc774 \uae30\ub85d\uc744 \uc804\ubd80 \uc9c0\uc6b8\uae4c\uc694?`);
    if (!ok) return;

    await deletePuzzlesByIds(generated.map((puzzle) => puzzle.id));
    splitPieces = [];
    mergedGrid = null;
    convertedGrid = null;
    combinedPieceGrid = null;
    loadedSessions = [];
    els.sessionList.innerHTML = "";
    els.sessionPreview.innerHTML = "";
    els.mergePreview.innerHTML = "";
    els.piecePreview.innerHTML = "";
    els.combinedPiecePreview.innerHTML = "";
    els.convertPreview.innerHTML = "";
    changePuzzle(builtInPuzzles[0].id);
    els.message.className = "message success";
    els.message.textContent = `${generated.length}\uac1c \uc0dd\uc131 \ud37c\uc990\uc744 \uc804\ubd80 \uc9c0\uc6e0\uc2b5\ub2c8\ub2e4.`;
  }

  async function deletePuzzlesByIds(ids) {
    const deletableIds = ids.filter((id) => !isBuiltInPuzzle(id));
    if (!deletableIds.length) return;

    removeLocalCustomPuzzles(deletableIds);
    removeLocalSessionsForPuzzleIds(deletableIds);
    await deleteFirebasePuzzleData(deletableIds);
    await loadPuzzles();
    setSaveStatus("\uc0ad\uc81c\ub428", "online");
  }

  function tick() {
    const elapsed = Math.floor((Date.now() - startedAt) / 1000);
    const total = seconds + elapsed;
    const minutes = String(Math.floor(total / 60)).padStart(2, "0");
    const secs = String(total % 60).padStart(2, "0");
    els.timer.textContent = `${minutes}:${secs}`;
  }

  async function loadSessions() {
    const selectedPuzzleId = els.reviewPuzzleSelect.value || els.mergePuzzleSelect.value;
    const sessions = [];
    const seen = new Set();

    localSessionIndex().forEach((key) => {
      const raw = localStorage.getItem(key);
      if (!raw) return;
      try {
        const data = JSON.parse(raw);
        if (data.puzzleId === selectedPuzzleId && Array.isArray(data.state)) {
          const id = `local:${key}`;
          sessions.push({ id, source: "local", ...data });
          seen.add(id);
        }
      } catch (error) {
        console.warn(error);
      }
    });

    if (db) {
      try {
        const snapshot = await db.collection("nonogramSessions").where("puzzleId", "==", selectedPuzzleId).get();
        snapshot.forEach((doc) => {
          const data = doc.data();
          if (data && Array.isArray(data.state)) {
            const id = `firebase:${doc.id}`;
            if (!seen.has(id)) sessions.push({ id, source: "firebase", ...data });
          }
        });
      } catch (error) {
        console.warn(error);
      }
    }

    loadedSessions = sessions.sort((a, b) => String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")));
    renderSessions();
    return loadedSessions;
  }

  function renderSessions() {
    els.sessionList.innerHTML = "";
    els.sessionPreview.innerHTML = "";

    if (!loadedSessions.length) {
      els.reviewSummary.textContent = text.noSessions;
      els.sessionList.innerHTML = `<div class="empty">${text.noSessions}</div>`;
      return;
    }

    els.reviewSummary.textContent = `${loadedSessions.length}${text.loadedSessions}`;
    loadedSessions.forEach((session, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "session-row";
      button.innerHTML = `<strong>${session.studentName || "guest"}</strong><span>${session.solved ? "\uc815\ub2f5" : "\uc9c4\ud589 \uc911"} · ${session.source}</span>`;
      button.addEventListener("click", () => renderSessionPreview(session));
      els.sessionList.appendChild(button);
      if (index === 0) renderSessionPreview(session);
    });
  }

  function renderSessionPreview(session) {
    els.sessionPreview.innerHTML = "";
    const title = document.createElement("h3");
    title.textContent = `${session.studentName || "guest"} · ${session.puzzleTitle || session.puzzleId}`;
    els.sessionPreview.appendChild(title);
    els.sessionPreview.appendChild(renderMiniGrid(session.state, { interactive: false }));
  }

  function mergeSessions() {
    const puzzle = puzzles.find((item) => item.id === els.mergePuzzleSelect.value) || currentPuzzle;
    const compatible = loadedSessions.filter((session) => {
      return session.puzzleId === puzzle.id &&
        Array.isArray(session.state) &&
        session.state.length === puzzle.grid.length &&
        session.state[0] &&
        session.state[0].length === puzzle.grid[0].length;
    });

    if (!compatible.length) {
      els.mergeSummary.textContent = text.noSessions;
      els.mergePreview.innerHTML = "";
      mergedGrid = null;
      return;
    }

    const mode = els.mergeMode.value;
    mergedGrid = puzzle.grid.map((row, rowIndex) => {
      return row.map((_, colIndex) => {
        const filled = compatible.filter((session) => session.state[rowIndex][colIndex] === 1).length;
        if (mode === "any") return filled > 0 ? 1 : 0;
        if (mode === "all") return filled === compatible.length ? 1 : 0;
        return filled >= Math.ceil(compatible.length / 2) ? 1 : 0;
      });
    });

    els.mergeSummary.textContent = `${compatible.length}\uac1c \uacb0\uacfc\ub97c \ud569\uccd0 ${mergedGrid[0].length}x${mergedGrid.length} \ud37c\uc990\uc744 \ub9cc\ub4e4\uc5c8\uc2b5\ub2c8\ub2e4.`;
    els.mergePreview.innerHTML = "";
    els.mergePreview.appendChild(renderMiniGrid(mergedGrid, { interactive: false }));
  }

  function makePieceId(parentId, pieceSize, row, col) {
    return `${parentId}-piece-${pieceSize}-${row}-${col}`.replace(/[^\w-]+/g, "_");
  }

  function splitSelectedPuzzle() {
    const source = puzzles.find((puzzle) => puzzle.id === els.splitPuzzleSelect.value) || currentPuzzle;
    const pieceSize = clampGridSize(els.pieceSize.value);
    const rowPieces = Math.ceil(source.grid.length / pieceSize);
    const colPieces = Math.ceil(source.grid[0].length / pieceSize);
    splitPieces = [];

    for (let pieceRow = 0; pieceRow < rowPieces; pieceRow += 1) {
      for (let pieceCol = 0; pieceCol < colPieces; pieceCol += 1) {
        const startRow = pieceRow * pieceSize;
        const startCol = pieceCol * pieceSize;
        const grid = source.grid.slice(startRow, startRow + pieceSize).map((row) => row.slice(startCol, startCol + pieceSize));
        splitPieces.push({
          id: makePieceId(source.id, pieceSize, pieceRow + 1, pieceCol + 1),
          title: `${source.title} ${pieceRow + 1}-${pieceCol + 1}`,
          grid: grid,
          parentId: source.id,
          parentTitle: source.title,
          piece: {
            row: pieceRow + 1,
            col: pieceCol + 1,
            rowPieces: rowPieces,
            colPieces: colPieces,
            startRow: startRow,
            startCol: startCol,
            width: grid[0].length,
            height: grid.length,
            parentWidth: source.grid[0].length,
            parentHeight: source.grid.length,
            pieceSize: pieceSize
          }
        });
      }
    }

    renderSplitPieces(source);
  }

  function renderSplitPieces(source) {
    els.piecePreview.innerHTML = "";
    if (!splitPieces.length) return;

    const header = document.createElement("h3");
    header.textContent = `${source.title} -> ${splitPieces.length} pieces`;
    els.piecePreview.appendChild(header);

    const list = document.createElement("div");
    list.className = "piece-list";
    splitPieces.forEach((piece) => {
      const item = document.createElement("div");
      item.className = "piece-card";
      const title = document.createElement("strong");
      title.textContent = piece.title;
      item.appendChild(title);
      item.appendChild(renderMiniGrid(piece.grid, { interactive: false }));
      list.appendChild(item);
    });
    els.piecePreview.appendChild(list);
    els.pieceSummary.textContent = `${source.grid[0].length}x${source.grid.length} \ud37c\uc990\uc744 ${splitPieces.length}\uac1c \uc870\uac01\uc73c\ub85c \ub098\ub20c\uc2b5\ub2c8\ub2e4.`;
  }

  async function saveSplitPieces() {
    if (!splitPieces.length) splitSelectedPuzzle();
    for (const piece of splitPieces) {
      saveLocalCustomPuzzle(piece);
      if (db) {
        try {
          await db.collection("nonogramPuzzles").doc(piece.id).set({
            title: piece.title,
            grid: piece.grid,
            width: piece.grid[0].length,
            height: piece.grid.length,
            parentId: piece.parentId,
            parentTitle: piece.parentTitle,
            piece: piece.piece,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
          }, { merge: true });
        } catch (error) {
          console.warn(error);
        }
      }
    }
    await loadPuzzles();
    els.pieceSummary.textContent = `${splitPieces.length}\uac1c \uc870\uac01 \ud37c\uc990\uc744 \ubaa9\ub85d\uc5d0 \ucd94\uac00\ud588\uc2b5\ub2c8\ub2e4.`;
    setSaveStatus(text.savedPuzzle, "online");
  }

  async function loadSessionsForPuzzleId(puzzleId) {
    const sessions = [];
    const seen = new Set();

    localSessionIndex().forEach((key) => {
      const raw = localStorage.getItem(key);
      if (!raw) return;
      try {
        const data = JSON.parse(raw);
        if (data.puzzleId === puzzleId && Array.isArray(data.state)) {
          const id = `local:${key}`;
          sessions.push({ id, source: "local", ...data });
          seen.add(id);
        }
      } catch (error) {
        console.warn(error);
      }
    });

    if (db) {
      try {
        const snapshot = await db.collection("nonogramSessions").where("puzzleId", "==", puzzleId).get();
        snapshot.forEach((doc) => {
          const data = doc.data();
          if (data && Array.isArray(data.state)) {
            const id = `firebase:${doc.id}`;
            if (!seen.has(id)) sessions.push({ id, source: "firebase", ...data });
          }
        });
      } catch (error) {
        console.warn(error);
      }
    }

    return sessions.sort((a, b) => {
      if (a.solved !== b.solved) return a.solved ? -1 : 1;
      return String(b.updatedAt || "").localeCompare(String(a.updatedAt || ""));
    });
  }

  async function combinePieceSessions() {
    const parent = puzzles.find((puzzle) => puzzle.id === els.combineParentSelect.value) || currentPuzzle;
    const pieces = puzzles.filter((puzzle) => puzzle.parentId === parent.id && puzzle.piece);
    combinedPieceGrid = makeBlankState(parent.grid);
    els.combinedPiecePreview.innerHTML = "";

    if (!pieces.length) {
      els.combinePieceSummary.textContent = "\uba3c\uc800 \uc6d0\ubcf8 \ud37c\uc990\uc744 \uc870\uac01\uc73c\ub85c \ucd94\uac00\ud558\uc138\uc694.";
      return;
    }

    let filledPieces = 0;
    const used = [];
    for (const piecePuzzle of pieces) {
      const sessions = await loadSessionsForPuzzleId(piecePuzzle.id);
      const session = sessions[0];
      if (!session) continue;
      filledPieces += 1;
      used.push(`${piecePuzzle.title}: ${session.studentName || "guest"}`);
      const piece = piecePuzzle.piece;
      session.state.forEach((row, rowIndex) => {
        row.forEach((value, colIndex) => {
          const targetRow = piece.startRow + rowIndex;
          const targetCol = piece.startCol + colIndex;
          if (targetRow < combinedPieceGrid.length && targetCol < combinedPieceGrid[0].length) {
            combinedPieceGrid[targetRow][targetCol] = value === 1 ? 1 : 0;
          }
        });
      });
    }

    if (!filledPieces) {
      els.combinePieceSummary.textContent = text.noSessions;
      combinedPieceGrid = null;
      return;
    }

    const title = document.createElement("h3");
    title.textContent = `${parent.title} combined`;
    els.combinedPiecePreview.appendChild(title);
    els.combinedPiecePreview.appendChild(renderMiniGrid(combinedPieceGrid, { interactive: false }));
    const usedList = document.createElement("div");
    usedList.className = "summary";
    usedList.textContent = used.join(" / ");
    els.combinedPiecePreview.appendChild(usedList);
    els.combinePieceSummary.textContent = `${pieces.length}\uac1c \uc870\uac01 \uc911 ${filledPieces}\uac1c\uc758 \ud559\uc0dd \ud480\uc774\ub97c \uc6d0\ub798 \uc704\uce58\uc5d0 \ubd99\uc600\uc2b5\ub2c8\ub2e4.`;
  }

  async function savePuzzleFromGrid(grid, title, options) {
    if (!grid) return;
    const meta = options || {};
    const puzzle = {
      id: meta.id || `custom-${Date.now()}`,
      title: title || "\uc0c8 \ud37c\uc990",
      grid: normalizeGrid(grid),
      parentId: meta.parentId || null,
      parentTitle: meta.parentTitle || "",
      piece: meta.piece || null
    };

    saveLocalCustomPuzzle(puzzle);

    if (db) {
      try {
        await db.collection("nonogramPuzzles").doc(puzzle.id).set({
          title: puzzle.title,
          grid: puzzle.grid,
          width: puzzle.grid[0].length,
          height: puzzle.grid.length,
          parentId: puzzle.parentId,
          parentTitle: puzzle.parentTitle,
          piece: puzzle.piece,
          createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
      } catch (error) {
        console.warn(error);
      }
    }

    await loadPuzzles();
    changePuzzle(puzzle.id);
    setSaveStatus(text.savedPuzzle, "online");
  }

  function renderMiniGrid(grid) {
    const wrap = document.createElement("div");
    wrap.className = "mini-grid";
    const size = cellSizeFor(grid);
    wrap.style.setProperty("--cell-size", `${Math.max(10, Math.min(22, size))}px`);
    wrap.style.gridTemplateColumns = `repeat(${grid[0].length}, var(--cell-size))`;
    grid.forEach((row) => {
      row.forEach((value) => {
        const cell = document.createElement("span");
        cell.className = value === 1 ? "mini-cell filled" : "mini-cell";
        wrap.appendChild(cell);
      });
    });
    return wrap;
  }

  function handleImageFile(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const image = new Image();
      image.onload = () => {
        uploadedImage = image;
        drawSourceImage();
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  }

  function drawSourceImage() {
    if (!uploadedImage) return;
    const canvas = els.imageCanvas;
    const max = 360;
    const scale = Math.min(max / uploadedImage.width, max / uploadedImage.height, 1);
    canvas.width = Math.max(1, Math.round(uploadedImage.width * scale));
    canvas.height = Math.max(1, Math.round(uploadedImage.height * scale));
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(uploadedImage, 0, 0, canvas.width, canvas.height);
  }

  function convertImageToGrid() {
    if (!uploadedImage) {
      els.convertSummary.textContent = "\uba3c\uc800 \uc774\ubbf8\uc9c0\ub97c \uc120\ud0dd\ud558\uc138\uc694.";
      return;
    }

    const width = clampGridSize(els.gridWidth.value);
    const height = clampGridSize(els.gridHeight.value);
    els.gridWidth.value = String(width);
    els.gridHeight.value = String(height);

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(uploadedImage, 0, 0, width, height);
    const data = ctx.getImageData(0, 0, width, height).data;
    const threshold = Number(els.threshold.value) || 150;
    const invert = els.invertImage.checked;
    convertedGrid = [];

    for (let row = 0; row < height; row += 1) {
      const line = [];
      for (let col = 0; col < width; col += 1) {
        const index = (row * width + col) * 4;
        const r = data[index];
        const g = data[index + 1];
        const b = data[index + 2];
        const alpha = data[index + 3];
        const brightness = 0.299 * r + 0.587 * g + 0.114 * b;
        const filled = alpha > 20 && (invert ? brightness >= threshold : brightness < threshold);
        line.push(filled ? 1 : 0);
      }
      convertedGrid.push(line);
    }

    els.convertPreview.innerHTML = "";
    els.convertPreview.appendChild(renderMiniGrid(convertedGrid, { interactive: false }));
    els.convertSummary.textContent = text.converted;
  }

  function switchTab(tabName) {
    els.tabs.forEach((tab) => tab.classList.toggle("active", tab.dataset.tab === tabName));
    els.panels.forEach((panel) => panel.classList.toggle("active", panel.id === `${tabName}Tab`));
  }

  function bindEvents() {
    els.tabs.forEach((tab) => tab.addEventListener("click", () => switchTab(tab.dataset.tab)));
    els.paintTool.addEventListener("click", () => setTool("paint"));
    els.markTool.addEventListener("click", () => setTool("mark"));
    els.eraseTool.addEventListener("click", () => setTool("erase"));
    els.checkBtn.addEventListener("click", checkAnswer);
    els.resetBtn.addEventListener("click", resetPuzzle);
    els.deletePuzzleBtn.addEventListener("click", deleteSelectedPuzzle);
    els.deleteAllGeneratedBtn.addEventListener("click", deleteAllGenerated);
    els.puzzleSelect.addEventListener("change", (event) => changePuzzle(event.target.value));
    els.reviewPuzzleSelect.addEventListener("change", () => {
      els.mergePuzzleSelect.value = els.reviewPuzzleSelect.value;
    });
    els.mergePuzzleSelect.addEventListener("change", () => {
      els.reviewPuzzleSelect.value = els.mergePuzzleSelect.value;
    });
    els.splitPuzzleSelect.addEventListener("change", () => {
      splitPieces = [];
      els.piecePreview.innerHTML = "";
    });
    els.combineParentSelect.addEventListener("change", () => {
      combinedPieceGrid = null;
      els.combinedPiecePreview.innerHTML = "";
    });
    els.studentName.addEventListener("change", () => {
      state = makeBlankState(currentPuzzle.grid);
      seconds = 0;
      startedAt = Date.now();
      loadProgress();
      renderBoard();
    });
    els.loadSessionsBtn.addEventListener("click", loadSessions);
    els.mergeBtn.addEventListener("click", async () => {
      els.reviewPuzzleSelect.value = els.mergePuzzleSelect.value;
      await loadSessions();
      mergeSessions();
    });
    els.saveMergedBtn.addEventListener("click", () => savePuzzleFromGrid(mergedGrid, els.mergedPuzzleTitle.value.trim() || "\ud569\uccd0\uc9c4 \ud37c\uc990"));
    els.splitPuzzleBtn.addEventListener("click", splitSelectedPuzzle);
    els.savePiecesBtn.addEventListener("click", saveSplitPieces);
    els.deletePiecesBtn.addEventListener("click", deletePiecesForSelectedParent);
    els.deleteAllPiecesBtn.addEventListener("click", deleteAllPieces);
    els.combinePiecesBtn.addEventListener("click", combinePieceSessions);
    els.saveCombinedBtn.addEventListener("click", () => {
      const parent = puzzles.find((puzzle) => puzzle.id === els.combineParentSelect.value);
      const title = parent ? `${parent.title} \uc870\uac01 \ud569\uce58\uae30` : "\uc870\uac01 \ud569\uce58\uae30";
      savePuzzleFromGrid(combinedPieceGrid, title);
    });
    els.imageInput.addEventListener("change", (event) => handleImageFile(event.target.files[0]));
    els.convertBtn.addEventListener("click", convertImageToGrid);
    els.saveConvertedBtn.addEventListener("click", () => savePuzzleFromGrid(convertedGrid, els.convertedPuzzleTitle.value.trim() || "\uc774\ubbf8\uc9c0 \ud37c\uc990"));

    window.addEventListener("beforeunload", () => {
      seconds += Math.floor((Date.now() - startedAt) / 1000);
      saveProgress(false);
    });
  }

  async function init() {
    setupFirebase();
    bindEvents();
    await loadPuzzles();
    state = makeBlankState(currentPuzzle.grid);
    loadProgress();
    renderBoard();
    window.setInterval(tick, 1000);
    tick();
  }

  init();
})();
